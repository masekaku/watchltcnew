<?php
/*
 * Working on this
 */
class phpfastcache_ext_regex extends phpfastcache_extensions {
    function delete($regx) {

    }
}